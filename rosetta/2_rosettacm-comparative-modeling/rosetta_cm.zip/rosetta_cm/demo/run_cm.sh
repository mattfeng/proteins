#!/bin/bash
~/rosetta_workshop/rosetta/main/source/bin/rosetta_scripts.linuxgccrelease  @ input_files/rosetta_cm.options
